import React, { useState } from "react";
import SideNav from "./SideNav.jsx";
import Header from "./Header.jsx";
import "../App.css";
function Layout({ children }) {
  const [isOppen, setIsOppen] = useState(true);
  const fullURL = window.location.href;
  const pathWithoutLayout = ["login", "registration"];
  return (
    <>
      {pathWithoutLayout.includes(fullURL.split("/").at(-1)) ? (
        <main>{children}</main>
      ) : (
        <div className={`row w-100 ${!isOppen ? "m-cloceNav" : null}`}>
          <div
            className={`
                        ${
                          isOppen
                            ? `${
                                window.matchMedia("(max-width: 500px)").matches
                                  ? "col-12"
                                  : window.matchMedia("(min-width: 700px)")
                                      .matches
                                  ? "col-2"
                                  : "col-4"
                              }`
                            : "col-1"
                        }
                        bg-black  fixed-top`}
          >
            <SideNav isOppen={isOppen} setIsOppen={setIsOppen} />
          </div>
          <div
            className={`
                        ${
                          isOppen
                            ? `${
                                window.matchMedia("(max-width: 500px)").matches
                                  ? "d-none"
                                  : window.matchMedia("(min-width: 700px)")
                                      .matches
                                  ? "m-25 col-10"
                                  : "col-8 ml-33"
                              }`
                            : "col-11"
                        } corictTheposition`}
          >
            <Header isOppen={isOppen} />
            {children}
          </div>
        </div>
      )}
    </>
  );
}

export default Layout;
