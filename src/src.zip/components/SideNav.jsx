import React, { useEffect, useState } from 'react'
import Logo from '../assets/images/Group.png'
import SmollLogo from '../assets/images/Smoll_ESTBN_Logo.png'
import './Sidenav.css'
import DashboardIcon from '@mui/icons-material/Dashboard';
import Groups2Icon from '@mui/icons-material/Groups2';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import AutoGraphIcon from '@mui/icons-material/AutoGraph';
import InventoryIcon from '@mui/icons-material/Inventory';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';

function SideNav({isOppen, setIsOppen}) { 
  return (
    <div className="bg-black position-relative vh-100" >
      {
        isOppen ?
          <button  type="button" className=" tuggle-menu text-darck bg-light" onClick={() => setIsOppen(false)}>
            <KeyboardArrowLeftIcon/>
          </button>
          :
          <button className={` tuggle-menu text-darck bg-light `}  type="button" onClick={() => setIsOppen(true)}>
            <KeyboardArrowRightIcon/>
          </button>
      }

      <div className={`text-light bg-black ${window.matchMedia("(max-width: 700px)").matches && !isOppen ? 'd-none':''}`} >
        <div className='imgeOfSidenav '> 
          {
            isOppen ?
          <img className='w-100' src={Logo} alt="Logo" />:
          <img className='w-100' src={SmollLogo} alt="Logo" />
          }
        </div>
        <div className={`
          ${isOppen ? 'allMinu' : 'allMinu m-0'}
          ${window.matchMedia("(max-width: 500px)").matches && isOppen ? 'justify-content-evenly':''}
        `} >
          <ul className={`
            ${isOppen ? 'list-unstyled' : 'list-unstyled allMinuInClose'}
            ${window.matchMedia("(max-width: 700px)").matches && !isOppen ? 'w-100':''}
          `}>
            {
              isOppen ? 
              <p className='Pmanu'>Menu</p>
              : null
            }
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} sbishlLiOfmenu`}>
              {
                !isOppen ?
                  <DashboardIcon />
                :
                  <>
                    <button className="sbishlLiOfmenu btn btn-toggle text-light align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false">
                      <span className='me-2 '>
                      <DashboardIcon />
                      </span>
                      Orders
                      <span className='ps-5 '>
                      <KeyboardArrowRightIcon/>
                      </span>
                    </button>
                    <div className="collapse" id="home-collapse">
                      <ul className="ms-5 btn-toggle-nav list-unstyled fw-normal pb-1 small">
                        <li>            
                            Overview
                        </li>
                        <li>            
                            Updates
                        </li>
                        <li>
                            Reports
                        </li>
                      </ul>
                    </div>
                  </>
              }
            </li>
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
              {
                !isOppen ?  
                  <Groups2Icon/>:
                  <>
                  <span className='me-2 '>
                    <Groups2Icon/>
                  </span>
                  Clents                  
                  </>
              }
            </li>
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
              {
                !isOppen ?  
                  <LocalShippingIcon/>:
                  <>
                  <span className='me-2 '>
                    <LocalShippingIcon/>
                  </span>
                  Service Vans                  
                  </>
              }
            </li>
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
            {
                !isOppen ?  
                  <CalendarTodayIcon/>:
                  <>
                  <span className='me-2 '>
                    <CalendarTodayIcon/>
                  </span>
                  Calendar                  
                  </>
              }
            </li>
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
            {
                !isOppen ?  
                  <ManageAccountsIcon/>:
                  <>
                  <span className='me-2 '>
                    <ManageAccountsIcon/>
                  </span>
                  Staff                  
                  </>
              }
            </li>
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
            {
                !isOppen ?  
                  <AutoGraphIcon/>:
                  <>
                  <span className='me-2 '>
                    <AutoGraphIcon/>
                  </span>
                  Analysis                  
                  </>
              }
            </li>
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
            {
                !isOppen ?  
                  <InventoryIcon/>:
                  <>
                  <span className='me-2 '>
                    <InventoryIcon/>
                  </span>
                  Stock                  
                  </>
              }
            </li>
          </ul>
          <div className={`${isOppen ? "Settings text-light" : 'Settings text-light allMinuInClose'}`}>
            <ul>
            <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
              {
                !isOppen ?  
                  <SettingsIcon/>:
                  <>
                  <span className='me-2 '>
                    <SettingsIcon/>
                  </span>
                  Settings                  
                  </>
              }
              </li>
              <li className={`${isOppen ? 'mb-1': 'p-2 m-1'} liOfmenu`}>
              {
                !isOppen ?  
                  <LogoutIcon/>:
                  <>
                  <span className='me-2 '>
                    <LogoutIcon/>
                  </span>
                  Log Out                  
                  </>
              }
              </li>
            </ul>  
          </div> 
        </div>
      </div>
    </div>
  )
}



export default SideNav