import { ReactComponent as Logo } from '../assets/svg/ESTBNLOGO.svg';
import ImageBK from '../assets/images/leftImage.png'

import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import { CREATE_ACCOUNT } from '../URLs/Apis';
import { useState } from 'react';
import axios from 'axios';

const Registartion = () => {

    const role = ['admin', 'supervisor', 'agent'];
    const gender = ['ذكر', 'انثي'];
    
    const handleSubmit = () => {
        const headers = { 'Authorization': 'Bearer 254|KSKd4yoSLnEauMckPA28IJBOIB7QddQC8I90QP7Te1cdeb0d' }; // auth header with bearer token

        axios.post(CREATE_ACCOUNT, userData, {headers}).then(response=>{
            console.log(response.data);
        }).catch(error=>{
            console.log(error.data);
        })
    }

    const[userData,setUserDate] = useState({
        first_name: '',
        last_name: '',
        username: '',
        phone_number: '',
        profile_photo: '',
        role: '',
        email: '',
        birthdate: '',
        password: '',
        gender: '',
        password_confirmation: ''
    })

    return ( 
        <div className="row m-0">
            <div className="col-md-5 col-sm-12 col-xs-12 col-lg-5 p-0">
                <div className="left_login_block">
                    <img src={ImageBK} className='imgBk' />
                    <div className='footerBlock'>
                        <div className='logo'>
                            <Logo />
                            <div className='textBlock mt-3'>
                                <h4><strong>Let’s get started</strong></h4>
                                <p>
                                    By joining our team, you'll be part of a dynamic and innovative company committed to providing top-notch car care services.
                                </p>
                            </div>
                        </div>

                        
                        
                    </div>
                </div>
            </div>

            <div className='col-md-7 col-xs-12 col-sm-12 col-lg-7'>
                <div className='formBlock'>
                    <h1>Create an account</h1>
                    <p>Enter your details below to create your account and get started</p>

                    <div className='formItems'>
                        
                        <div className='row p-0 m-0'>
                            <div className='col-6 formSyle m-0 p-0'>
                                    <div className='form-group mt-3'>
                                        <TextField 
                                        value={userData.first_name}
                                         className="w-100" 
                                         label="First Name" 
                                         variant="outlined" 
                                         onChange={e => {
                                            setUserDate({...userData, first_name: e.target.value})
                                         }}
                                         />  
                                    </div>
                                
                            </div>
                            <div className='col-6 formStyle m-0'>
                                <div className='form-group mt-3'>
                                    <TextField 
                                    className="w-100" 
                                        label="Last Name" 
                                        value={userData.last_name}
                                        variant="outlined" 
                                        onChange={e => {
                                            setUserDate({...userData, last_name: e.target.value})
                                         }}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className='row p-0 m-0'>
                            <div className='col-6 m-0 p-0'>
                                <div className='form-group mt-3'>
                                    <Autocomplete
                                        disablePortal
                                        options={role}
                                        renderInput={(params) => <TextField {...params} label="Role" />}
                                        onChange={(event, newValue) => setUserDate({...userData, role: newValue})}
                                        />
                                </div>

                                <div className='form-group mt-3'>
                                    <Autocomplete
                                        disablePortal
                                        options={gender}
                                        renderInput={(params) => <TextField {...params} label="Gender" />}
                                        onChange={(event, newValue) => setUserDate({...userData, gender: newValue})}

                                        />
                                </div>

                               

                               
                            </div>

                            <div className='col-6 formSyle m-0'>
                                <div className='form-group mt-3'>
                                    <TextField 
                                        className="w-100" 
                                        label="Mobile Number" 
                                        variant="outlined" 
                                        value={userData.phone_number}
                                        onChange={e => {
                                            setUserDate({...userData, phone_number: e.target.value})
                                        }}
                                    /> 
                                </div>

                                <div className='form-group mt-3'>
                                    <TextField className="w-100"
                                         label="Birth Date" 
                                         type='date' 
                                         placeholder='DD/MM/YYYY'
                                         slotProps={{
                                            inputLabel: {
                                              shrink: true,
                                            },
                                          }}
                                          value={userData.birthdate}
                                          onChange={e=>{
                                            setUserDate({...userData, birthdate: e.target.value})
                                          }}
                                         /> 
                                </div>

                               

                               
                            </div>

                            <div className='form-group mt-3 p-0'>
                                <TextField 
                                     value={userData.username}
                                     className="w-100" 
                                     label="Username" 
                                     variant="outlined"
                                     onChange={e=> {
                                        setUserDate({...userData, username: e.target.value})
                                     }}
                                 /> 
                            </div>

                            <div className='form-group mt-3 p-0'>
                                <TextField 
                                    className="w-100" 
                                    label="Email" 
                                    variant="outlined" 
                                    value={userData.email}
                                    onChange={e=>{
                                        setUserDate({...userData, email: e.target.value})
                                    }}
                                /> 
                            </div>

                        </div>

                        <div className='row p-0 m-0'>
                            <div className='col-6 m-0 p-0'>
                                <div className='form-group mt-3'>
                                    <TextField 
                                        className="w-100" 
                                        label="Password" 
                                        type='password' 
                                        variant="outlined" 
                                        value={userData.password}
                                        onChange={e=>{
                                            setUserDate({...userData, password: e.target.value})
                                        }}
                                    /> 
                                </div>
                            </div>

                            <div className='col-6 formSyle m-0'>
                                <div className='form-group mt-3'>
                                    <TextField 
                                        className="w-100" 
                                        label="Confirm Password" 
                                        type='password' 
                                        variant="outlined" 
                                        value={userData.password_confirmation}
                                        onChange={e=>{
                                            setUserDate({...userData, password_confirmation: e.target.value})
                                        }}
                                    /> 
                                </div>
                               
                            </div>

                            <div className="col-12 p-0">
                                <button onClick={handleSubmit} className='btn btn-primary w-100 mt-4'>Submit</button>
                            </div>

                        </div>

                        
                        
                    </div>
                </div>
            </div>
        </div>
     );
}
 
export default Registartion;