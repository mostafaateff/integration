import Logo from '../../assets/images/Group.png'
import BodyPic from '../../assets/images/Pic.png'
import './Login.css';
import {Link } from "react-router-dom";
import { OPERATORS_LOGIN } from '../../URLs/Apis';
import { useState } from 'react';
import axios from 'axios';


function Login() {

    const handleSubmit = () => {
        axios.post(OPERATORS_LOGIN, loginReqData).then(res=>{
            console.log(res.data);
        }).catch(e=>{
            console.log(e.data);
        })
    }

    const[loginReqData,setLoginReqData] = useState({
        email: '',
        password: '',
        device_name: 'mobile',
    })

    return (
            <div class="row login">
                <div class="col sideForImg">
                    <div className="header bg-black">
                        <div className="logoHeader">
                        <img className='loginLogo' src={Logo} alt="Logo" />
                        <p className=' mainText'>Login to manage orders and imporove efficiency</p>
                        </div>
                        <img className=' mainImg' src={BodyPic} alt="Car Imges" />
                    </div>
                </div>
                <div class="col sideForinfo">
                    <div className="container welcom">
                        <div>
                            <h1 className='title'>Welcome back Ziad</h1>
                            <p className='welcomeP'>Glad to see you again</p>
                            <div class="mb-3 inpForm">
                                <label for="exampleFormControlInput1" class="form-label label">Email </label>
                                <input 
                                    type="email" 
                                    class="form-control" 
                                    id="exampleFormControlInput1" 
                                    placeholder="name@example.com"
                                    value={loginReqData.email}
                                    onChange={e=>{
                                        setLoginReqData({...loginReqData, email: e.target.value})
                                    }}
                                />
                            </div>
                            <div class="mb-3 inpForm">
                                <label for="exampleFormControlInput1" class="form-label label">Password</label>
                                <input 
                                    type="password" 
                                    class="form-control" 
                                    id="exampleFormControlInput1" 
                                    placeholder="Enter your password"
                                    value={loginReqData.password}
                                    onChange={e=>{
                                        setLoginReqData({...loginReqData, password: e.target.value})
                                    }}
                                />
                            </div>
                            <div className=" rememberTheName">
                                <div >
                                <input type="checkbox" className='px-3 d-inline'/><span className='rememberMe'>Remember me</span>
                                </div>
                                <Link to='/'>
                                <p>Forgot password?</p>
                                </Link>
                            </div>
                            <button onClick={handleSubmit} type="button" class="btn btn-primary submetButton">Login</button>
                        </div>
                    </div>
                    <div className="noAccount">
                        Don't have an account?
                        <Link to='/registration'>
                        <span className='register'>Register</span>
                        </Link>
                    </div>
                </div>
            </div>
    );
}

export default Login;
