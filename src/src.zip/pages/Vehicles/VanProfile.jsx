import VanProfileCard from "../../components/Cards/VanProfileCard";
import VanCardBtns from "../../components/VanCardBtns";
import OrderDetailsCard from "../../components/OrderDetailsCard ";
import Equipment from "../../components/Equipment";
import StaffVans from "../../components/StaffVans";
import { useEffect, useState } from "react";
import WorkingDays from "../../components/WorkingDays";
import { useLocation } from "react-router";
import ServicesVanProfile from "../../components/ServicesVanProfile";

// function ListInfoItem({ label, value }) {
//   return (
//     <h6
//       className="d-flex justify-content-between align-items-center text-secondary grayColor"
//       style={{ lineHeight: "26.24px" }}
//     >
//       {label}
//       <span
//         className=" text-dark grayColor"
//         style={{
//           fontWeight: "600px",
//           lineHeight: "26.24px",
//           marginLeft: "auto",
//         }}
//       >
//         {value}
//       </span>
//     </h6>
//   );
// }

const VanProfile = () => {
  const [activePage, setActivePage] = useState("orders");
  const location = useLocation();
  const { vehicle, id } = location.state || {};

  useEffect(() => {
    console.log(location.state.id);
  }, []);
  return (
    <>
      <div>
        <div className="container mt-4 ">
          <VanCardBtns activePage={activePage} setActivePage={setActivePage} />
        </div>
      </div>
      <div className="mr-5  row">
        <div className="col-lg-4 col-md-4 col-sm-12">
          <VanProfileCard
            vehicleData={vehicle}
            vehicleId={id}
            setActivePage={setActivePage}
          />
        </div>
        <div className="col-lg-8 col-md-8 col-sm-12">
          {activePage === "orders" && <OrderDetailsCard />}
          {activePage === "StaffVans" && <StaffVans />}
          {activePage === "Equipment" && <Equipment />}
          {activePage === "WorkingDays" && <WorkingDays />}
          {activePage === "Services" && <ServicesVanProfile />}
        </div>
      </div>
    </>
  );
};

export default VanProfile;
