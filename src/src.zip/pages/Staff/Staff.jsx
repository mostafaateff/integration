import React, { useState } from 'react'
import SearchIcon from '@mui/icons-material/Search';
import TuneIcon from '@mui/icons-material/Tune';
import AddIcon from '@mui/icons-material/Add';
import Star from '../../assets/svg/star.svg'
import StaffImage from '../../assets/images/StaffImage.png'
import './Staff.css';
import {Box, Drawer, Slider } from '@mui/material';
import XIcon from '../../assets/svg/xIcon.svg'
import ArrUp from '../../assets/svg/ArrUp.svg'
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';


function Staff() {
    const StaffData = {
        "Joined": "Jan 13,2022",
        "Service Van": "Van # 02",
        "Mobile Number": "01157501306",
        "Email": "AliAhmed@gmail.com",
        "Experience": "5 years"
    }
    const [open, setOpen] = useState(false);
    const toggleDrawer = (newOpen) => () => {
        setOpen(newOpen);
    };
    const jobsTitle = ['engineers', 'drivers', "technicians"]
    const [rangeExperResult, setRangeExperResult] = useState(0)
    const [rangeRatesResult, setRangeRatesResult] = useState(0)
    const [filterBy, setFilterby] = useState({
        engineers: '',
        drivers: '',  
        technicians: '',  
    })
    //  onChange={e => {
    //     setUserDate({...userData, first_name: e.target.value})
    //  }}
    const [openFilterjob, setOpenFilterjob] = useState(true)
    const [openFilterdate, setOpenFilterdate] = useState(true)
    const [openFilterEx, setOpenFilterEx] = useState(true)
    const [openFilterRate, setOpenFilterRate] = useState(true)
    
    const submitFilterBy = () => {

        console.log(filterBy);
        setRangeExperResult(0)
        setRangeRatesResult(0)
    }


  return (
    <div className='container position-relative'>
        <Drawer
            anchor={'right'}
            open={open}
            onClose={toggleDrawer(false)}
        >
            <Box sx={{ width: 350, padding: 3 }} role="presentation" >
                <div className="filterBy-title">
                    <span className='resetAll'>Reset all</span>
                    <span className='filterBy_theTitle'>Filter By</span>
                    <div onClick={toggleDrawer(false)}>
                        <img className='' src={XIcon} alt="" />
                    </div>
                </div>
                <div className="filterBy-groping">
                    <div className="filterBy-jobTitle">
                        <div className="front" onClick={() => setOpenFilterjob(!openFilterjob)}>
                            <span>Job Title</span>
                            <img src={ArrUp} className={`${openFilterjob ? null : 'rotat180'}`} alt="" />
                        </div> 
                        <div className={`back ${openFilterjob ? null : 'd-none'}`}>
                            {
                                jobsTitle.map(e =>{
                                    return(
                                        <div key={e} className="form-check">
                                            <input 
                                                className="form-check-input" 
                                                type="checkbox" value=""
                                                id="flexCheckDefault"
                                                onChange={t => {
                                                    setFilterby({...filterBy, e: t.target.value})
                                                }}
                                            />
                                            <label className="form-check-label" for="flexCheckDefault">
                                                {e}
                                            </label>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>
                    <div className="filterBy-joineddate">
                        <div className="front" onClick={() => setOpenFilterdate(!openFilterdate)}>
                            <span>Joined date</span>
                            <img src={ArrUp} className={`${openFilterdate ? null : 'rotat180'}`} alt="" />
                        </div>
                        <div className={`back ${openFilterdate ? null : 'd-none'}`}>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DemoContainer components={['DatePicker']}>
                                <DatePicker label="Chooes The Date" />
                            </DemoContainer>
                        </LocalizationProvider>
                        </div>
                    </div>
                    <div className="filterBy-experience">
                        <div className="front" onClick={() => setOpenFilterEx(!openFilterEx)}>
                            <span>Experience</span>
                            <img src={ArrUp} className={`${openFilterEx ? null : 'rotat180'}`} alt="" />
                        </div>
                        <div className={`back ${openFilterEx ? null : 'd-none'}`}>
                            <Slider
                                onChange={(e) => {setRangeExperResult(e.target.value)}}
                                aria-label="Temperature"
                                defaultValue={0}
                                valueLabelDisplay="auto"
                                step={1}
                                marks
                                min={0}
                                max={10}
                            />
                            <div className="range-from-to">
                                <div className="from">0 years</div>
                                <div className="range-result">{rangeExperResult}</div>
                                <div className="to">+10 years</div>
                            </div>
                        </div>
                    </div>
                    <div className="filterBy-rates">
                        <div className="front" onClick={() => setOpenFilterRate(!openFilterRate)}>
                            <span>Rates</span>
                            <img src={ArrUp} className={`${openFilterRate ? null : 'rotat180'}`} alt="" />
                        </div>
                        <div className={`back ${openFilterRate ? null : 'd-none'}`}>
                            <Slider
                                onChange={(e) => {setRangeRatesResult(e.target.value)}}
                                aria-label="Temperature"
                                defaultValue={0}
                                valueLabelDisplay="auto"
                                step={1}
                                marks
                                min={0}
                                max={10}
                            />
                            <div className="range-from-to">
                                <div className="from">0 star</div>
                                <div className="range-result">{rangeRatesResult}</div>
                                <div className="to">5 stars</div>
                            </div>
                        </div>
                    </div>
                    <button onSubmit={submitFilterBy} className="filterBy-Sub">Show {0} results</button>
                </div>
            </Box>
        </Drawer>

      <div className="staff-hader">
        <div className="staff-header_title">Staff</div>
        <div className="staff-header_edete">
            <div className="staff-header_edete-icon mainBorder me-15"><SearchIcon/></div>
            <div onClick={toggleDrawer(true)} className="staff-header_edete-icon mainBorder me-15"><TuneIcon/></div>
            <div className="staff-header_edete-icon mainBorder d-flex "><AddIcon/><span className='ms-1 d-flex'>Add Member</span></div>
        </div>
      </div>
      <div className="container">
        <div className="staff-cards mainBorder">
            {
                [0,1,2,3,4,5].map((e)=>{
                    return (
                        <div key={e} className="staff-cards-card mainBorder">
                        <div className="staff-cards-card_title">
                            <div className="staff-cards-card_jobT">Engineer</div>
                            <div className="staff-cards-card_rank">
                                4.5
                                <img src={Star} alt="" />
                            </div>
                        </div>
                        <div className="staff-cards-card_staffInfo">
                            <div className="staff-cards-card_staffInfo_img">
                            <img src={StaffImage} alt="" />
                            </div>
                            <div className="staff-cards-card_staffInfo_name">
                                Ail Ahmed Ali
                            </div>
                        </div>
                        <div className="staff-cards-card_staffDate">
                            {
                                Object.entries(StaffData).map(e => {
                                return( <div className="staff-cards-card_staffDate_join">
                                        <div className="front">{e[0]}</div>
                                        <div className="data">{e[1]}</div>
                                    </div>)
                                })
                            }
                        </div>
                    </div>
                    )
                })
            }
        </div>
      </div>
    </div>
  )
}

export default Staff
